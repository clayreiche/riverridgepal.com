<form method="get" id="searchform" action="<?php bloginfo('home'); ?>/">
<div><input type="text" value="<?php if ( function_exists('the_search_query') ) the_search_query(); ?>" name="s" id="s" />
<input src="<?php bloginfo('stylesheet_directory'); ?>/images/go.jpg" type="image" id="searchsubmit" value="Search" />
</div>
</form>
